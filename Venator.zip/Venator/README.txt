How to play:

Goal: Kill all enemies in the level.
You lose if all your units perish.

Controls:
Tab: Swap between units

For firing mode you press the FireWeapon button and it goes into targeting mode.
T: During targeting mode T changes the target selected which is highlighted in yellow or green if using heal.
There will be a second button such as Fire, Heal, or Boost that will confirm the action based on the target selected.

Fire Weapon will damage enemies based on the player's weapon.

Grenade will toss a grenade that does consistant damage and radius. Warning: Can hit your allies with it.

Heal will heal a selected unit.

Adreline will give your allies action points at the cost of the user's action points

Blue has rifle and grenade
White has sniper and heal
Orange has shotgun and adreline

All units have 4 action points and each action costs 2 points this includes moving.

To move click on a tile based on what ally you have selected.
Tiles you can move to are highlighted in red.

If you run out of action points (AP) you have to click on the End Turn button to swap to the enemy team that will take their actions. Enemy Units also have only 4 AP.

2 types of enemies: One that charges with a sword
and the other that finds cover and shoots with a gun
The Gun that the enemy has is on their side so you can tell which ones you have to target first.
